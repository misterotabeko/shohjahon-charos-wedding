// To'y vaqti (ISO format)
const eventTime = new Date("2025-05-25T00:00:00").getTime();

function updateCountdown() {
  const now  = Date.now();
  const diff = eventTime - now;

  if (diff <= 0) {
    clearInterval(timer);
    document.getElementById('countdown').innerHTML =
      '<p style="font-size:1.2rem; color:#c0392b;">Marosim boshlandi!</p>';
    return;
  }

  const sec     = 1000,
        min     = sec * 60,
        hr      = min * 60,
        day     = hr  * 24;

  const days    = Math.floor(diff / day),
        hours   = Math.floor((diff % day) / hr),
        minutes = Math.floor((diff % hr) / min),
        seconds = Math.floor((diff % min) / sec);

  document.getElementById('days').textContent    = days;
  document.getElementById('hours').textContent   = hours;
  document.getElementById('minutes').textContent = minutes;
  document.getElementById('seconds').textContent = seconds;
}

const timer = setInterval(updateCountdown, 1000);
updateCountdown();